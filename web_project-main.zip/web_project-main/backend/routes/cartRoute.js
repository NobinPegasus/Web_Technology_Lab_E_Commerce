const express = require("express");
const router = express.Router();
const {
  AllCart,
  CreateCart,
  UpdateCart,
  DeleteCart,
  SingleCart,
} = require("../controller/cartController");

router.post("/createcart",  CreateCart);
router.get("/allcart",  AllCart);
router.get("/singlecart", SingleCart);
router.put("/updatecart", UpdateCart);
router.delete("/deletecart", DeleteCart);

module.exports = router;
