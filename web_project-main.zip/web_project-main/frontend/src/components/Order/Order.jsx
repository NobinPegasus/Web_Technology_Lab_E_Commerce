import React, { useEffect, useState } from "react";
import { buyerOrder } from "../../Api/Api";
import "./Order.css"

const Order = () => {
    const [orders,setOrders] = useState([]);
  useEffect(() => {
    const id = localStorage.getItem("id")
    const getOrder = async () => {
      const res = await buyerOrder(id);
      setOrders(res.data)
    };
    getOrder();
  }, []);
  return (
    <>
      <div className="order_div">
        {orders.map((order, i) => (
          <div key={i} className="order_element">
            <h3 style={{ color: "#2B4865" }}>
              Product quantity :
              <span style={{ color: "gray", marginLeft: "1rem" }}>
                {order.products.length}
              </span>
            </h3>
            <h3 style={{ color: "#2B4865" }}>
              Product price :
              <span style={{ color: "gray", marginLeft: "1rem" }}>
                ${order.amount}
              </span>
            </h3>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <h3 style={{ color: "#2B4865" }}>
                Status :
                <span style={{ color: "#FF1E00", marginLeft: "1rem" }}>
                  {order.status}
                </span>
              </h3>
              <button className="order_btn">Payment</button>
            </div>
          </div>
        ))}
      </div>
    </>
  );
};

export default Order;
