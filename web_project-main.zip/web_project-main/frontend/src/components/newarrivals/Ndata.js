const Ndata = [
  {
    cover: "./images/arrivals/arrivals1.png",
    name: "Sunglass",
    price: "150",
  },
  {
    cover: "./images/arrivals/arrivals2.png",
    name: "Makeup",
    price: "250",
  },
  {
    cover: "./images/arrivals/arrivals3.png",
    name: "Smart Watch",
    price: "50",
  },
  {
    cover: "./images/arrivals/arrivals4.png",
    name: "Lipstick",
    price: "15",
  },
  {
    cover: "./images/arrivals/arrivals5.png",
    name: "Green Plant",
    price: "10",
  },
  {
    cover: "./images/arrivals/arrivals6.png",
    name: "Bonsai tree",
    price: "400",
  },
]

export default Ndata
