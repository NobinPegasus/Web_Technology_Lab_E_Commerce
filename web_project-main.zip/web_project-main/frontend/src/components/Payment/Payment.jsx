import React, { useState } from 'react'
import StripeCheckout from "react-stripe-checkout";
const key =
  "pk_test_51LbXKWSDu7wDpHJSgT1Dka5Nxa1xccNCff8C8MugEWys4zbJIZtwPMvZZpquUKU2uR8ccpinfk8bfrd73GWzjWLR00B6Wky3Gj";
const Payment = () => {
const [stripeToken, setStripeToken] = useState(null);
    const onToken = (token) =>{
      console.log(token)
        setStripeToken(token)
    }
  return (
    <>
      <div
        style={{
          height: "100vh",
          display: "flex",
          alignitems: "center",
          justifyContent: "center",
        }}
      >
        <StripeCheckout
          name="Ecommerce Shop"
          image=""
          billingAddress
          shipingAddress
          description="Your total is $20"
          amount={2000}
          token={onToken}
          stripeKey={key}
        >
          <button
            style={{
              border: "none",
              width: 120,
              borderRadius: 5,
              padding: "20px",
              backgroundColor: "#e94560",
              color: "white",
              fontWeight: "600",
              cursor: "pointer",
              marginTop:"10rem"
            }}
          >
            Pay Now
          </button>
        </StripeCheckout>
      </div>
    </>
  );
}

export default Payment